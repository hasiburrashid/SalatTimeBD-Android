# Salat Time BD - Native Android Application

Kotlin ও Jetpack Compose দিয়ে তৈরি নেটিভ অ্যান্ড্রয়েড অ্যাপ (বাংলাদেশের নামাজের সময়সূচি, এলার্ম, ফিকহী ওয়াক্ত-শেষ হিসাব)।

## GitHub Actions দিয়ে APK বিল্ড

1. কোড `main` ব্র্যাঞ্চে push করুন।
2. রিপোজিটরির **Actions** ট্যাবে "Build APK" workflow চলবে (হাতে চালাতে: Run workflow)।
3. সফল হলে রানের পেজের নিচে **Artifacts** থেকে `SalatTimeBD-debug-apk` ডাউনলোড করুন; জিপের ভেতরে `app-debug.apk`।

## Android Studio-তে চালানো

'SalatTimeBD-Android' ফোল্ডারটি Open করুন, Gradle Sync শেষে Run দিন।
