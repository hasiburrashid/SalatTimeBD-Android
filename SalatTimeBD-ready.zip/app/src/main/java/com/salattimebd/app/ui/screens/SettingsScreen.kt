package com.salattimebd.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.salattimebd.app.data.BANGLADESH_DISTRICTS
import com.salattimebd.app.data.preferences.UserSettings

private val CALCULATION_METHODS = listOf(
    1 to "University of Islamic Sciences, Karachi (বাংলাদেশে প্রচলিত)",
    2 to "Islamic Society of North America (ISNA)",
    3 to "Muslim World League",
    4 to "Umm Al-Qura University, Makkah",
    5 to "Egyptian General Authority of Survey"
)

private val ASR_SCHOOLS = listOf(
    1 to "হানাফী (ছায়া দ্বিগুণ)",
    0 to "শাফেয়ী / মালেকী / হাম্বলী (ছায়া একগুণ)"
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    userSettings: UserSettings,
    onBack: () -> Unit,
    onUpdateGps: (Boolean) -> Unit,
    onSelectDistrict: (String, Double, Double) -> Unit,
    onUpdateCalculationMethod: (Int) -> Unit,
    onUpdateAsrSchool: (Int) -> Unit,
    onUpdateNumerals: (Boolean) -> Unit
) {
    var showDistrictDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("সেটিংস") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "ফিরে যান")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary,
                    navigationIconContentColor = MaterialTheme.colorScheme.onPrimary
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // অবস্থান
            SettingsCard(title = "অবস্থান") {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("GPS ব্যবহার করুন", fontWeight = FontWeight.Medium)
                        Text(
                            "বর্তমান অবস্থান অনুযায়ী সময় দেখাবে",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                    Switch(checked = userSettings.useGps, onCheckedChange = onUpdateGps)
                }
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { showDistrictDialog = true }
                        .padding(top = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("জেলা", fontWeight = FontWeight.Medium)
                        Text(
                            userSettings.selectedDistrict,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    Text("পরিবর্তন", color = MaterialTheme.colorScheme.primary)
                }
            }

            // গণনা পদ্ধতি
            SettingsCard(title = "গণনা পদ্ধতি") {
                CALCULATION_METHODS.forEach { (id, label) ->
                    RadioRow(
                        label = label,
                        selected = userSettings.calculationMethodId == id,
                        onClick = { onUpdateCalculationMethod(id) }
                    )
                }
            }

            // আসরের মাযহাব
            SettingsCard(title = "আসরের ওয়াক্ত (মাযহাব)") {
                ASR_SCHOOLS.forEach { (id, label) ->
                    RadioRow(
                        label = label,
                        selected = userSettings.asrSchool == id,
                        onClick = { onUpdateAsrSchool(id) }
                    )
                }
            }

            // সংখ্যা
            SettingsCard(title = "প্রদর্শন") {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("বাংলা সংখ্যা (১২৩)", modifier = Modifier.weight(1f))
                    Switch(checked = userSettings.useBengaliNumerals, onCheckedChange = onUpdateNumerals)
                }
            }
        }
    }

    if (showDistrictDialog) {
        AlertDialog(
            onDismissRequest = { showDistrictDialog = false },
            title = { Text("জেলা নির্বাচন করুন") },
            text = {
                LazyColumn {
                    items(BANGLADESH_DISTRICTS) { d ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    onSelectDistrict(d.nameBn, d.latitude, d.longitude)
                                    showDistrictDialog = false
                                }
                                .padding(vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = !userSettings.useGps && userSettings.selectedDistrict == d.nameBn,
                                onClick = null
                            )
                            Text(d.nameBn, modifier = Modifier.padding(start = 12.dp))
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showDistrictDialog = false }) { Text("বন্ধ করুন") }
            }
        )
    }
}

@Composable
private fun SettingsCard(title: String, content: @Composable () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Column(modifier = Modifier.padding(top = 8.dp)) { content() }
        }
    }
}

@Composable
private fun RadioRow(label: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RadioButton(selected = selected, onClick = onClick)
        Text(label, modifier = Modifier.padding(start = 8.dp))
    }
}
