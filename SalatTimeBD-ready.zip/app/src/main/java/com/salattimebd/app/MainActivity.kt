package com.salattimebd.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.android.gms.tasks.CancellationTokenSource
import com.salattimebd.app.alarm.AlarmRefresher
import com.salattimebd.app.alarm.PrayerAlarmScheduler
import com.salattimebd.app.data.preferences.UserPreferencesRepository
import com.salattimebd.app.data.preferences.UserSettings
import com.salattimebd.app.data.repository.DailyPrayerData
import com.salattimebd.app.data.repository.PrayerRepository
import com.salattimebd.app.data.repository.Resource
import com.salattimebd.app.ui.screens.DiagnosticsScreen
import com.salattimebd.app.ui.screens.HomeScreen
import com.salattimebd.app.ui.screens.SettingsScreen
import com.salattimebd.app.ui.theme.SalatTimeBDTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainActivity : ComponentActivity() {

    private lateinit var prayerRepo: PrayerRepository
    private lateinit var prefsRepo: UserPreferencesRepository
    private lateinit var alarmScheduler: PrayerAlarmScheduler
    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private var testMediaPlayer: MediaPlayer? = null
    private var activeCustomAudioPrayerId: String? = null

    private val notificationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    private val locationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { grants ->
            if (grants.values.any { it }) {
                fetchGpsLocation()
            } else {
                lifecycleScope.launch {
                    val s = prefsRepo.userSettingsFlow.first()
                    prefsRepo.updateLocation(false, s.selectedDistrict, s.latitude, s.longitude)
                    Toast.makeText(this@MainActivity, "অবস্থানের অনুমতি দেওয়া হয়নি", Toast.LENGTH_SHORT).show()
                }
            }
        }

    private fun hasLocationPermission(): Boolean =
        ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    @SuppressLint("MissingPermission")
    private fun fetchGpsLocation() {
        fusedLocationClient
            .getCurrentLocation(Priority.PRIORITY_BALANCED_POWER_ACCURACY, CancellationTokenSource().token)
            .addOnSuccessListener { loc ->
                if (loc != null) {
                    lifecycleScope.launch {
                        prefsRepo.updateLocation(true, "বর্তমান অবস্থান", loc.latitude, loc.longitude)
                    }
                } else {
                    Toast.makeText(this, "অবস্থান পাওয়া যায়নি, GPS চালু আছে কি দেখুন", Toast.LENGTH_LONG).show()
                }
            }
            .addOnFailureListener {
                Toast.makeText(this, "অবস্থান আনতে ব্যর্থ হয়েছে", Toast.LENGTH_LONG).show()
            }
    }

    private fun playPreview(uriString: String?) {
        testMediaPlayer?.release()
        testMediaPlayer = null
        if (uriString.isNullOrEmpty()) return
        try {
            testMediaPlayer = MediaPlayer().apply {
                setDataSource(this@MainActivity, Uri.parse(uriString))
                prepare()
                setOnCompletionListener { it.release(); if (testMediaPlayer === it) testMediaPlayer = null }
                start()
            }
        } catch (e: Exception) {
            testMediaPlayer = null
            Toast.makeText(this, "অডিও চালানো যায়নি", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onDestroy() {
        testMediaPlayer?.release()
        testMediaPlayer = null
        super.onDestroy()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        prayerRepo = PrayerRepository(this)
        prefsRepo = UserPreferencesRepository(this)
        alarmScheduler = PrayerAlarmScheduler(this)
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        setContent {
            SalatTimeBDTheme {
                val navController = rememberNavController()
                val userSettings by prefsRepo.userSettingsFlow.collectAsState(initial = UserSettings())
                var prayerState by remember { mutableStateOf<Resource<DailyPrayerData>>(Resource.Loading) }

                // Audio Picker Launcher for custom Adhan file
                val audioPickerLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.GetContent()
                ) { uri: Uri? ->
                    if (uri != null && activeCustomAudioPrayerId != null) {
                        lifecycleScope.launch {
                            val id = activeCustomAudioPrayerId!!
                            val oldConfig = when (id) {
                                "fajr" -> userSettings.fajrAlarm
                                "dhuhr" -> userSettings.dhuhrAlarm
                                "asr" -> userSettings.asrAlarm
                                "maghrib" -> userSettings.maghribAlarm
                                else -> userSettings.ishaAlarm
                            }
                            // পিকারের অস্থায়ী URI পরে কাজ করে না, তাই ফাইলটি অ্যাপের নিজস্ব স্টোরেজে কপি করা হচ্ছে
                            val savedUri = withContext(Dispatchers.IO) {
                                try {
                                    val target = File(filesDir, "adhan_$id")
                                    contentResolver.openInputStream(uri)?.use { input ->
                                        target.outputStream().use { output -> input.copyTo(output) }
                                    }
                                    Uri.fromFile(target).toString()
                                } catch (e: Exception) {
                                    null
                                }
                            }
                            if (savedUri != null) {
                                prefsRepo.updateAlarmConfig(
                                    id,
                                    oldConfig.copy(customAudioUri = savedUri, soundMode = "custom_adhan")
                                )
                                Toast.makeText(this@MainActivity, "আজান অডিও সংরক্ষিত হয়েছে", Toast.LENGTH_SHORT).show()
                            } else {
                                Toast.makeText(this@MainActivity, "অডিও ফাইল সংরক্ষণ করা যায়নি", Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                }

                LaunchedEffect(userSettings.latitude, userSettings.longitude, userSettings.calculationMethodId, userSettings.asrSchool) {
                    prayerState = Resource.Loading
                    val result = prayerRepo.getPrayerTimes(
                        latitude = userSettings.latitude,
                        longitude = userSettings.longitude,
                        locationName = userSettings.selectedDistrict,
                        methodId = userSettings.calculationMethodId,
                        schoolId = userSettings.asrSchool,
                        forceRefresh = false
                    )
                    prayerState = result
                }

                // সময়সূচি লোড হলে বা এলার্ম সেটিংস বদলালে আজ ও আগামীকালের এলার্ম নতুন করে সেট হবে
                LaunchedEffect(
                    prayerState is Resource.Success,
                    userSettings.fajrAlarm,
                    userSettings.dhuhrAlarm,
                    userSettings.asrAlarm,
                    userSettings.maghribAlarm,
                    userSettings.ishaAlarm
                ) {
                    if (prayerState is Resource.Success) {
                        AlarmRefresher.refresh(this@MainActivity)
                    }
                }

                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    NavHost(navController = navController, startDestination = "home") {
                        composable("home") {
                            HomeScreen(
                                prayerDataState = prayerState,
                                userSettings = userSettings,
                                onManualRefresh = {
                                    lifecycleScope.launch {
                                        prayerState = Resource.Loading
                                        prayerState = prayerRepo.getPrayerTimes(
                                            latitude = userSettings.latitude,
                                            longitude = userSettings.longitude,
                                            locationName = userSettings.selectedDistrict,
                                            methodId = userSettings.calculationMethodId,
                                            schoolId = userSettings.asrSchool,
                                            forceRefresh = true
                                        )
                                    }
                                },
                                onNavigateToSettings = { navController.navigate("settings") },
                                onNavigateToDiagnostics = { navController.navigate("diagnostics") },
                                onAlarmToggle = { id, enabled ->
                                    lifecycleScope.launch {
                                        val oldConfig = when (id) {
                                            "fajr" -> userSettings.fajrAlarm
                                            "dhuhr" -> userSettings.dhuhrAlarm
                                            "asr" -> userSettings.asrAlarm
                                            "maghrib" -> userSettings.maghribAlarm
                                            else -> userSettings.ishaAlarm
                                        }
                                        prefsRepo.updateAlarmConfig(id, oldConfig.copy(enabled = enabled))
                                    }
                                },
                                onSaveAlarmConfig = { id, updatedConfig ->
                                    lifecycleScope.launch {
                                        prefsRepo.updateAlarmConfig(id, updatedConfig)
                                    }
                                },
                                onSelectAudio = { prayerId ->
                                    activeCustomAudioPrayerId = prayerId
                                    audioPickerLauncher.launch("audio/*")
                                },
                                onPreviewAudio = { mode, uriStr ->
                                    if (mode == "custom_adhan") playPreview(uriStr)
                                }
                            )
                        }
                        composable("settings") {
                            SettingsScreen(
                                userSettings = userSettings,
                                onBack = { navController.popBackStack() },
                                onUpdateGps = { useGps ->
                                    if (!useGps) {
                                        lifecycleScope.launch {
                                            prefsRepo.updateLocation(false, userSettings.selectedDistrict, userSettings.latitude, userSettings.longitude)
                                        }
                                    } else if (hasLocationPermission()) {
                                        fetchGpsLocation()
                                    } else {
                                        locationPermissionLauncher.launch(
                                            arrayOf(
                                                Manifest.permission.ACCESS_FINE_LOCATION,
                                                Manifest.permission.ACCESS_COARSE_LOCATION
                                            )
                                        )
                                    }
                                },
                                onSelectDistrict = { name, lat, lng ->
                                    lifecycleScope.launch {
                                        prefsRepo.updateLocation(false, name, lat, lng)
                                    }
                                },
                                onUpdateCalculationMethod = { mId ->
                                    lifecycleScope.launch {
                                        prefsRepo.updateCalculationSettings(mId, userSettings.asrSchool)
                                    }
                                },
                                onUpdateAsrSchool = { sId ->
                                    lifecycleScope.launch {
                                        prefsRepo.updateCalculationSettings(userSettings.calculationMethodId, sId)
                                    }
                                },
                                onUpdateNumerals = { useBn ->
                                    lifecycleScope.launch {
                                        prefsRepo.updateBengaliNumerals(useBn)
                                    }
                                }
                            )
                        }
                        composable("diagnostics") {
                            DiagnosticsScreen(
                                lastSyncTimestamp = userSettings.lastSyncTimestamp,
                                lastSyncStatus = userSettings.lastSyncStatus,
                                onBack = { navController.popBackStack() }
                            )
                        }
                    }
                }
            }
        }
    }
}