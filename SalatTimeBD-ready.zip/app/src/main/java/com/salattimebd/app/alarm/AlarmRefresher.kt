package com.salattimebd.app.alarm

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.salattimebd.app.data.preferences.UserPreferencesRepository
import com.salattimebd.app.data.repository.PrayerRepository
import com.salattimebd.app.data.repository.Resource
import kotlinx.coroutines.flow.first

/** আজ ও আগামীকালের এলার্ম সেটিংস অনুযায়ী নতুন করে সেট করে। */
object AlarmRefresher {
    suspend fun refresh(context: Context) {
        val app = context.applicationContext
        val settings = UserPreferencesRepository(app).userSettingsFlow.first()
        val repo = PrayerRepository(app)
        val scheduler = PrayerAlarmScheduler(app)
        val configs = settings.alarmConfigs()

        for (offset in 0..1) {
            val result = repo.getPrayerTimes(
                latitude = settings.latitude,
                longitude = settings.longitude,
                locationName = settings.selectedDistrict,
                methodId = settings.calculationMethodId,
                schoolId = settings.asrSchool,
                forceRefresh = false,
                dayOffset = offset
            )
            if (result is Resource.Success) {
                scheduler.scheduleAllPrayers(result.data.timings, configs, offset)
            }
        }
    }
}

class AlarmRefreshWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        return try {
            AlarmRefresher.refresh(applicationContext)
            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }
}
