package com.salattimebd.app.alarm

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.salattimebd.app.data.preferences.PrayerAlarmConfig
import com.salattimebd.app.util.PrayerTiming
import java.util.Calendar
import java.util.TimeZone

class PrayerAlarmScheduler(private val context: Context) {
    private val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager

    companion object {
        const val EXTRA_PRAYER_ID = "extra_prayer_id"
        const val EXTRA_PRAYER_NAME = "extra_prayer_name"
        const val EXTRA_IS_REMINDER = "extra_is_reminder"
        const val EXTRA_MINUTES_BEFORE = "extra_minutes_before"
        const val EXTRA_SOUND_MODE = "extra_sound_mode"
        const val EXTRA_AUDIO_URI = "extra_audio_uri"
        const val ACTION_PRAYER_ALARM = "com.salattimebd.app.ACTION_PRAYER_ALARM"
        private const val REQ_BASE_START = 1000
        private const val REQ_BASE_REMINDER = 2000
        private const val DAY_STEP = 100
        private val PRAYER_IDS = listOf("fajr", "dhuhr", "asr", "maghrib", "isha")
    }

    fun canScheduleExactAlarms(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            alarmManager.canScheduleExactAlarms()
        } else {
            true
        }
    }

    /**
     * dayOffset = 0 হলে আজকের, 1 হলে আগামীকালের এলার্ম সেট হয়।
     * প্রতিটি দিনের জন্য আলাদা request code ব্যবহার হয়, তাই দুই দিনের এলার্ম একসাথে থাকতে পারে।
     */
    fun scheduleAllPrayers(
        timings: List<PrayerTiming>,
        configs: Map<String, PrayerAlarmConfig>,
        dayOffset: Int = 0
    ) {
        val now = System.currentTimeMillis()
        timings.filter { it.isObligatory }.forEach { timing ->
            val prayerId = timing.id
            val config = configs[prayerId] ?: PrayerAlarmConfig()
            val baseId = PRAYER_IDS.indexOf(prayerId).coerceAtLeast(0)
            val startReqCode = REQ_BASE_START + baseId + dayOffset * DAY_STEP
            val reminderReqCode = REQ_BASE_REMINDER + baseId + dayOffset * DAY_STEP

            // আগের সেট করা এলার্ম আগে বাতিল (কনফিগ বদলালে পুরনোটা যেন না থাকে)
            cancelAlarm(startReqCode)
            cancelAlarm(reminderReqCode)

            if (!config.enabled) return@forEach

            val prayerEpoch = calculateEpoch(timing.startTime, dayOffset)
            if (prayerEpoch > now) {
                scheduleExact(prayerEpoch, startReqCode, prayerId, timing.nameBn, false, 0, config.soundMode, config.customAudioUri)
            }

            if (config.minutesBefore > 0) {
                val reminderEpoch = prayerEpoch - (config.minutesBefore * 60 * 1000L)
                if (reminderEpoch > now) {
                    scheduleExact(reminderEpoch, reminderReqCode, prayerId, timing.nameBn, true, config.minutesBefore, config.soundMode, config.customAudioUri)
                }
            }
        }
    }

    private fun scheduleExact(triggerTime: Long, reqCode: Int, id: String, name: String, isRem: Boolean, minBefore: Int, sound: String, uri: String?) {
        val intent = Intent(context, PrayerAlarmReceiver::class.java).apply {
            action = ACTION_PRAYER_ALARM
            putExtra(EXTRA_PRAYER_ID, id)
            putExtra(EXTRA_PRAYER_NAME, name)
            putExtra(EXTRA_IS_REMINDER, isRem)
            putExtra(EXTRA_MINUTES_BEFORE, minBefore)
            putExtra(EXTRA_SOUND_MODE, sound)
            putExtra(EXTRA_AUDIO_URI, uri)
        }
        val pendingIntent = PendingIntent.getBroadcast(
            context, reqCode, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        if (canScheduleExactAlarms()) {
            alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerTime, pendingIntent)
        } else {
            alarmManager.set(AlarmManager.RTC_WAKEUP, triggerTime, pendingIntent)
        }
    }

    private fun cancelAlarm(reqCode: Int) {
        val intent = Intent(context, PrayerAlarmReceiver::class.java).apply {
            action = ACTION_PRAYER_ALARM
        }
        val pendingIntent = PendingIntent.getBroadcast(
            context, reqCode, intent,
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        if (pendingIntent != null) {
            alarmManager.cancel(pendingIntent)
            pendingIntent.cancel()
        }
    }

    private fun calculateEpoch(time24: String, dayOffset: Int): Long {
        val parts = time24.split(":")
        val cal = Calendar.getInstance(TimeZone.getTimeZone("Asia/Dhaka"))
        cal.add(Calendar.DAY_OF_YEAR, dayOffset)
        cal.set(Calendar.HOUR_OF_DAY, parts.getOrNull(0)?.trim()?.toIntOrNull() ?: 0)
        cal.set(Calendar.MINUTE, parts.getOrNull(1)?.trim()?.toIntOrNull() ?: 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        return cal.timeInMillis
    }
}
