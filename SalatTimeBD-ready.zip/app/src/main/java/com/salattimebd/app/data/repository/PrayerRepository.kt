package com.salattimebd.app.data.repository

import android.content.Context
import com.google.gson.Gson
import com.salattimebd.app.data.api.AlAdhanApiService
import com.salattimebd.app.data.model.AlAdhanData
import com.salattimebd.app.data.preferences.UserPreferencesRepository
import com.salattimebd.app.util.BengaliUtils
import com.salattimebd.app.util.FiqhEndTimeCalculator
import com.salattimebd.app.util.PrayerTiming
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import java.util.TimeZone

sealed class Resource<out T> {
    object Loading : Resource<Nothing>()
    data class Success<out T>(val data: T) : Resource<T>()
    data class Error(val message: String) : Resource<Nothing>()
}

data class DailyPrayerData(
    val timings: List<PrayerTiming>,
    val gregorianDateBn: String,
    val hijriDateBn: String,
    val locationName: String,
    val fromCache: Boolean
)

class PrayerRepository(context: Context) {
    private val appContext = context.applicationContext
    private val api by lazy { AlAdhanApiService.create() }
    private val cache = appContext.getSharedPreferences("prayer_cache", Context.MODE_PRIVATE)
    private val settingsRepo = UserPreferencesRepository(appContext)
    private val gson = Gson()

    private class Fetched(val data: AlAdhanData, val fromCache: Boolean)

    suspend fun getPrayerTimes(
        latitude: Double,
        longitude: Double,
        locationName: String,
        methodId: Int,
        schoolId: Int,
        forceRefresh: Boolean,
        dayOffset: Int = 0
    ): Resource<DailyPrayerData> = withContext(Dispatchers.IO) {
        try {
            val date = dateString(dayOffset)
            val today = fetchOrCache(date, latitude, longitude, methodId, schoolId, forceRefresh)

            // মধ্যরাত হিসাবের জন্য পরের দিনের ফজর (না পেলে আজকেরটাই ব্যবহার হবে)
            val nextDayFajr: String? = if (dayOffset == 0) {
                try {
                    fetchOrCache(dateString(dayOffset + 1), latitude, longitude, methodId, schoolId, false)
                        .data.timings?.fajr
                } catch (e: Exception) {
                    null
                }
            } else null

            val t = today.data.timings ?: throw IllegalStateException("সার্ভার থেকে সময়সূচি পাওয়া যায়নি")
            val timings = FiqhEndTimeCalculator.calculatePrayerBoundaries(
                fajr = t.fajr ?: "",
                sunrise = t.sunrise ?: "",
                dhuhr = t.dhuhr ?: "",
                asr = t.asr ?: "",
                maghrib = t.maghrib ?: "",
                isha = t.isha ?: "",
                nextDayFajr = nextDayFajr?.split(" ")?.get(0),
                asrSchool = if (schoolId == 1) "Hanafi" else "Shafi"
            )

            Resource.Success(
                DailyPrayerData(
                    timings = timings,
                    gregorianDateBn = gregorianBn(today.data),
                    hijriDateBn = hijriBn(today.data),
                    locationName = locationName,
                    fromCache = today.fromCache
                )
            )
        } catch (e: Exception) {
            Resource.Error("নামাজের সময় আনা যায়নি: ${e.message ?: "ইন্টারনেট সংযোগ পরীক্ষা করুন"}")
        }
    }

    private suspend fun fetchOrCache(
        date: String,
        lat: Double,
        lng: Double,
        method: Int,
        school: Int,
        forceRefresh: Boolean
    ): Fetched {
        val key = "$date|${String.format(Locale.US, "%.3f|%.3f", lat, lng)}|$method|$school"
        val cachedJson = cache.getString(key, null)
        val cachedData: AlAdhanData? = cachedJson?.let {
            try {
                gson.fromJson(it, AlAdhanData::class.java)
            } catch (e: Exception) {
                null
            }
        }

        if (!forceRefresh && cachedData?.timings != null) {
            return Fetched(cachedData, true)
        }

        return try {
            val response = api.getTimings(date, lat, lng, method, school)
            val data = response.data
            if (data?.timings == null) throw IllegalStateException("অবৈধ সার্ভার উত্তর")
            cache.edit().putString(key, gson.toJson(data)).apply()
            pruneCache()
            settingsRepo.updateSyncStatus(System.currentTimeMillis(), "সফল ($date)")
            Fetched(data, false)
        } catch (e: Exception) {
            settingsRepo.updateSyncStatus(
                System.currentTimeMillis(),
                "ব্যর্থ: ${e.message ?: e.javaClass.simpleName}"
            )
            if (cachedData?.timings != null) Fetched(cachedData, true) else throw e
        }
    }

    private fun pruneCache() {
        val keep = (0..3).map { dateString(it) }.toSet()
        val editor = cache.edit()
        for (k in cache.all.keys) {
            if (k.substringBefore('|') !in keep) editor.remove(k)
        }
        editor.apply()
    }

    private fun dateString(offsetDays: Int): String {
        val cal = Calendar.getInstance(TimeZone.getTimeZone("Asia/Dhaka"))
        cal.add(Calendar.DAY_OF_YEAR, offsetDays)
        val fmt = SimpleDateFormat("dd-MM-yyyy", Locale.US)
        fmt.timeZone = TimeZone.getTimeZone("Asia/Dhaka")
        return fmt.format(cal.time)
    }

    private fun gregorianBn(data: AlAdhanData): String {
        val g = data.date?.gregorian ?: return ""
        val day = g.day ?: return ""
        val month = BengaliUtils.gregorianMonthName(g.month?.number ?: 0)
        val year = g.year ?: ""
        return "$day $month $year"
    }

    private fun hijriBn(data: AlAdhanData): String {
        val h = data.date?.hijri ?: return ""
        val day = (h.day ?: return "").trimStart('0')
        val month = BengaliUtils.hijriMonthName(h.month?.number ?: 0)
        val year = h.year ?: ""
        return "$day $month $year হিজরি"
    }
}
