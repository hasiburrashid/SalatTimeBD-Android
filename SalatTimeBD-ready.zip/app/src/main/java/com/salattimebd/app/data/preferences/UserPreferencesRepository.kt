package com.salattimebd.app.data.preferences

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.doublePreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException

private val Context.salatDataStore: DataStore<Preferences> by preferencesDataStore(name = "salat_settings")

/** প্রতিটি ওয়াক্তের এলার্ম কনফিগ। soundMode: "default" অথবা "custom_adhan" */
data class PrayerAlarmConfig(
    val enabled: Boolean = true,
    val minutesBefore: Int = 0,
    val soundMode: String = "default",
    val customAudioUri: String? = null
)

data class UserSettings(
    val useGps: Boolean = false,
    val selectedDistrict: String = "ঢাকা",
    val latitude: Double = 23.8103,
    val longitude: Double = 90.4125,
    val calculationMethodId: Int = 1,
    /** AlAdhan school: 0 = শাফেয়ী/জমহুর, 1 = হানাফী */
    val asrSchool: Int = 1,
    val useBengaliNumerals: Boolean = true,
    val fajrAlarm: PrayerAlarmConfig = PrayerAlarmConfig(),
    val dhuhrAlarm: PrayerAlarmConfig = PrayerAlarmConfig(),
    val asrAlarm: PrayerAlarmConfig = PrayerAlarmConfig(),
    val maghribAlarm: PrayerAlarmConfig = PrayerAlarmConfig(),
    val ishaAlarm: PrayerAlarmConfig = PrayerAlarmConfig(),
    val lastSyncTimestamp: Long = 0L,
    val lastSyncStatus: String = "এখনো সিঙ্ক হয়নি"
) {
    fun alarmConfigs(): Map<String, PrayerAlarmConfig> = mapOf(
        "fajr" to fajrAlarm,
        "dhuhr" to dhuhrAlarm,
        "asr" to asrAlarm,
        "maghrib" to maghribAlarm,
        "isha" to ishaAlarm
    )

    fun alarmFor(prayerId: String): PrayerAlarmConfig = alarmConfigs()[prayerId] ?: PrayerAlarmConfig()
}

class UserPreferencesRepository(context: Context) {
    private val store = context.applicationContext.salatDataStore

    private object Keys {
        val USE_GPS = booleanPreferencesKey("use_gps")
        val DISTRICT = stringPreferencesKey("district")
        val LAT = doublePreferencesKey("lat")
        val LNG = doublePreferencesKey("lng")
        val METHOD = intPreferencesKey("method")
        val SCHOOL = intPreferencesKey("school")
        val BN_NUMERALS = booleanPreferencesKey("bn_numerals")
        val SYNC_TS = longPreferencesKey("sync_ts")
        val SYNC_STATUS = stringPreferencesKey("sync_status")

        fun enabled(id: String) = booleanPreferencesKey("${id}_enabled")
        fun minutes(id: String) = intPreferencesKey("${id}_minutes")
        fun sound(id: String) = stringPreferencesKey("${id}_sound")
        fun audio(id: String) = stringPreferencesKey("${id}_audio")
    }

    val userSettingsFlow: Flow<UserSettings> = store.data
        .catch { e ->
            if (e is IOException) emit(emptyPreferences()) else throw e
        }
        .map { p ->
            val d = UserSettings()
            fun alarm(id: String) = PrayerAlarmConfig(
                enabled = p[Keys.enabled(id)] ?: true,
                minutesBefore = p[Keys.minutes(id)] ?: 0,
                soundMode = p[Keys.sound(id)] ?: "default",
                customAudioUri = p[Keys.audio(id)]
            )
            UserSettings(
                useGps = p[Keys.USE_GPS] ?: d.useGps,
                selectedDistrict = p[Keys.DISTRICT] ?: d.selectedDistrict,
                latitude = p[Keys.LAT] ?: d.latitude,
                longitude = p[Keys.LNG] ?: d.longitude,
                calculationMethodId = p[Keys.METHOD] ?: d.calculationMethodId,
                asrSchool = p[Keys.SCHOOL] ?: d.asrSchool,
                useBengaliNumerals = p[Keys.BN_NUMERALS] ?: d.useBengaliNumerals,
                fajrAlarm = alarm("fajr"),
                dhuhrAlarm = alarm("dhuhr"),
                asrAlarm = alarm("asr"),
                maghribAlarm = alarm("maghrib"),
                ishaAlarm = alarm("isha"),
                lastSyncTimestamp = p[Keys.SYNC_TS] ?: d.lastSyncTimestamp,
                lastSyncStatus = p[Keys.SYNC_STATUS] ?: d.lastSyncStatus
            )
        }

    suspend fun updateAlarmConfig(prayerId: String, config: PrayerAlarmConfig) {
        store.edit { p ->
            p[Keys.enabled(prayerId)] = config.enabled
            p[Keys.minutes(prayerId)] = config.minutesBefore
            p[Keys.sound(prayerId)] = config.soundMode
            val uri = config.customAudioUri
            if (uri.isNullOrEmpty()) p.remove(Keys.audio(prayerId)) else p[Keys.audio(prayerId)] = uri
        }
    }

    suspend fun updateLocation(useGps: Boolean, district: String, latitude: Double, longitude: Double) {
        store.edit { p ->
            p[Keys.USE_GPS] = useGps
            p[Keys.DISTRICT] = district
            p[Keys.LAT] = latitude
            p[Keys.LNG] = longitude
        }
    }

    suspend fun updateCalculationSettings(methodId: Int, asrSchool: Int) {
        store.edit { p ->
            p[Keys.METHOD] = methodId
            p[Keys.SCHOOL] = asrSchool
        }
    }

    suspend fun updateBengaliNumerals(useBengali: Boolean) {
        store.edit { p -> p[Keys.BN_NUMERALS] = useBengali }
    }

    suspend fun updateSyncStatus(timestamp: Long, status: String) {
        store.edit { p ->
            p[Keys.SYNC_TS] = timestamp
            p[Keys.SYNC_STATUS] = status
        }
    }
}
