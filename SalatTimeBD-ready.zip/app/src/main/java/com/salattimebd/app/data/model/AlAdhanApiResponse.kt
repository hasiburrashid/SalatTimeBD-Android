package com.salattimebd.app.data.model

import com.google.gson.annotations.SerializedName

data class AlAdhanApiResponse(
    @SerializedName("code") val code: Int? = null,
    @SerializedName("status") val status: String? = null,
    @SerializedName("data") val data: AlAdhanData? = null
)

data class AlAdhanData(
    @SerializedName("timings") val timings: AlAdhanTimings? = null,
    @SerializedName("date") val date: AlAdhanDate? = null
)

data class AlAdhanTimings(
    @SerializedName("Fajr") val fajr: String? = null,
    @SerializedName("Sunrise") val sunrise: String? = null,
    @SerializedName("Dhuhr") val dhuhr: String? = null,
    @SerializedName("Asr") val asr: String? = null,
    @SerializedName("Maghrib") val maghrib: String? = null,
    @SerializedName("Isha") val isha: String? = null
)

data class AlAdhanDate(
    @SerializedName("readable") val readable: String? = null,
    @SerializedName("gregorian") val gregorian: AlAdhanGregorian? = null,
    @SerializedName("hijri") val hijri: AlAdhanHijri? = null
)

data class AlAdhanGregorian(
    @SerializedName("day") val day: String? = null,
    @SerializedName("year") val year: String? = null,
    @SerializedName("month") val month: AlAdhanMonth? = null
)

data class AlAdhanHijri(
    @SerializedName("day") val day: String? = null,
    @SerializedName("year") val year: String? = null,
    @SerializedName("month") val month: AlAdhanMonth? = null
)

data class AlAdhanMonth(
    @SerializedName("number") val number: Int? = null,
    @SerializedName("en") val en: String? = null
)
