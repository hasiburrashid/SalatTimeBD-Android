package com.salattimebd.app

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.salattimebd.app.alarm.AlarmRefreshWorker
import java.util.concurrent.TimeUnit

class SalatApp : Application() {

    companion object {
        const val CHANNEL_PRAYER_START = "prayer_start"
        const val CHANNEL_PRAYER_REMINDER = "prayer_reminder"
        const val WORK_ALARM_REFRESH = "salat_alarm_refresh"
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannels()
        scheduleAlarmRefreshWork()
    }

    private fun createNotificationChannels() {
        val nm = getSystemService(NotificationManager::class.java)

        val startChannel = NotificationChannel(
            CHANNEL_PRAYER_START,
            "নামাজের ওয়াক্ত শুরু",
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = "প্রতিটি ওয়াক্ত শুরু হলে জানানো হবে"
            enableVibration(true)
        }

        val reminderChannel = NotificationChannel(
            CHANNEL_PRAYER_REMINDER,
            "ওয়াক্তের আগে রিমাইন্ডার",
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = "ওয়াক্ত শুরুর আগে আগাম সতর্কবার্তা"
            enableVibration(true)
        }

        nm.createNotificationChannel(startChannel)
        nm.createNotificationChannel(reminderChannel)
    }

    /** প্রতি ৬ ঘণ্টায় আজ ও আগামীকালের এলার্ম নতুন করে সেট করে। */
    private fun scheduleAlarmRefreshWork() {
        val request = PeriodicWorkRequestBuilder<AlarmRefreshWorker>(6, TimeUnit.HOURS).build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            WORK_ALARM_REFRESH,
            ExistingPeriodicWorkPolicy.KEEP,
            request
        )
    }
}
