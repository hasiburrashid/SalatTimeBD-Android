package com.salattimebd.app.ui.screens

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.app.NotificationManagerCompat
import com.salattimebd.app.alarm.PrayerAlarmScheduler
import com.salattimebd.app.util.BengaliUtils
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DiagnosticsScreen(
    lastSyncTimestamp: Long,
    lastSyncStatus: String,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val exactAlarmOk = PrayerAlarmScheduler(context).canScheduleExactAlarms()
    val notificationsOk = NotificationManagerCompat.from(context).areNotificationsEnabled()

    val syncText = if (lastSyncTimestamp <= 0L) {
        "এখনো সিঙ্ক হয়নি"
    } else {
        val fmt = SimpleDateFormat("dd/MM/yyyy hh:mm a", Locale.US)
        fmt.timeZone = TimeZone.getTimeZone("Asia/Dhaka")
        BengaliUtils.toBengaliDigits(fmt.format(Date(lastSyncTimestamp)))
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("ডায়াগনস্টিকস") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "ফিরে যান")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary,
                    navigationIconContentColor = MaterialTheme.colorScheme.onPrimary
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            InfoCard("সর্বশেষ সিঙ্ক", syncText, lastSyncStatus)
            InfoCard(
                "নোটিফিকেশন",
                if (notificationsOk) "চালু আছে" else "বন্ধ আছে",
                if (notificationsOk) "আজান ও রিমাইন্ডার দেখাতে পারবে" else "ফোনের সেটিংস থেকে অ্যাপের নোটিফিকেশন চালু করুন"
            )
            InfoCard(
                "সঠিক সময়ের এলার্ম",
                if (exactAlarmOk) "অনুমোদিত" else "অনুমোদিত নয়",
                if (exactAlarmOk) "এলার্ম ঠিক ওয়াক্তে বাজবে"
                else "অনুমতি না দিলে এলার্ম কয়েক মিনিট দেরিতে বাজতে পারে"
            )

            if (!exactAlarmOk && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                Button(
                    onClick = {
                        val intent = Intent(
                            Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                            Uri.parse("package:${context.packageName}")
                        )
                        context.startActivity(intent)
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("এলার্মের অনুমতি দিন") }
            }

            Button(
                onClick = {
                    val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${context.packageName}"))
                    context.startActivity(intent)
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("অ্যাপের সেটিংস খুলুন") }
        }
    }
}

@Composable
private fun InfoCard(title: String, value: String, note: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(title, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
            Text(value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text(note, style = MaterialTheme.typography.bodySmall)
        }
    }
}
