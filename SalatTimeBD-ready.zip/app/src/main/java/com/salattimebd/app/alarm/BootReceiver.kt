package com.salattimebd.app.alarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/** ফোন রিস্টার্ট / সময় বা টাইমজোন বদল / অ্যাপ আপডেটের পর এলার্ম আবার সেট করে। */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                AlarmRefresher.refresh(context)
            } catch (e: Exception) {
                // পরের ৬ ঘণ্টার WorkManager রানে আবার চেষ্টা হবে
            } finally {
                pending.finish()
            }
        }
    }
}
