package com.salattimebd.app.util

object BengaliUtils {
    private val digits = charArrayOf('০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯')

    private val gregorianMonths = listOf(
        "জানুয়ারি", "ফেব্রুয়ারি", "মার্চ", "এপ্রিল", "মে", "জুন",
        "জুলাই", "আগস্ট", "সেপ্টেম্বর", "অক্টোবর", "নভেম্বর", "ডিসেম্বর"
    )

    private val hijriMonths = listOf(
        "মুহাররম", "সফর", "রবিউল আউয়াল", "রবিউস সানী", "জমাদিউল আউয়াল", "জমাদিউস সানী",
        "রজব", "শা'বান", "রমাযান", "শাওয়াল", "যিলকদ", "যিলহজ্জ"
    )

    fun toBengaliDigits(value: Int): String = toBengaliDigits(value.toString())

    fun toBengaliDigits(value: String): String {
        val sb = StringBuilder(value.length)
        for (c in value) {
            sb.append(if (c in '0'..'9') digits[c - '0'] else c)
        }
        return sb.toString()
    }

    fun localize(text: String, useBengali: Boolean): String =
        if (useBengali) toBengaliDigits(text) else text

    fun gregorianMonthName(month1to12: Int): String =
        gregorianMonths.getOrElse(month1to12 - 1) { "" }

    fun hijriMonthName(month1to12: Int): String =
        hijriMonths.getOrElse(month1to12 - 1) { "" }

    /** "17:35" -> "সন্ধ্যা ৫:৩৫" (বা ইংরেজি সংখ্যায় "সন্ধ্যা 5:35")। */
    fun formatTime12(time24: String, useBengali: Boolean): String {
        return try {
            val parts = time24.split(":")
            val h = parts[0].trim().toInt()
            val m = parts[1].trim().toInt()
            val h12 = when {
                h == 0 -> 12
                h > 12 -> h - 12
                else -> h
            }
            val period = when (h) {
                in 3..5 -> "ভোর"
                in 6..11 -> "সকাল"
                in 12..14 -> "দুপুর"
                in 15..16 -> "বিকাল"
                in 17..18 -> "সন্ধ্যা"
                else -> "রাত"
            }
            val body = String.format(java.util.Locale.US, "%d:%02d", h12, m)
            "$period ${localize(body, useBengali)}"
        } catch (e: Exception) {
            time24
        }
    }

    /** সেকেন্ড থেকে "২ ঘণ্টা ১৫ মিনিট ০৩ সেকেন্ড" ধরনের কাউন্টডাউন। */
    fun formatCountdown(totalSeconds: Int, useBengali: Boolean): String {
        val s = totalSeconds.coerceAtLeast(0)
        val h = s / 3600
        val m = (s % 3600) / 60
        val sec = s % 60
        val text = if (h > 0) {
            "$h ঘণ্টা $m মিনিট $sec সেকেন্ড"
        } else {
            "$m মিনিট $sec সেকেন্ড"
        }
        return localize(text, useBengali)
    }
}
