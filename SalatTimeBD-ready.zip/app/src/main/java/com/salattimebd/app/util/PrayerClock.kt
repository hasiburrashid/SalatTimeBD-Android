package com.salattimebd.app.util

import java.util.Calendar
import java.util.TimeZone

data class PrayerStatus(
    val current: PrayerTiming?,
    val next: PrayerTiming,
    val secondsToNext: Int
)

object PrayerClock {
    private val dhaka: TimeZone = TimeZone.getTimeZone("Asia/Dhaka")

    fun secondsOfDay(nowMillis: Long): Int {
        val c = Calendar.getInstance(dhaka)
        c.timeInMillis = nowMillis
        return c.get(Calendar.HOUR_OF_DAY) * 3600 + c.get(Calendar.MINUTE) * 60 + c.get(Calendar.SECOND)
    }

    fun minutesOf(time24: String): Int {
        return try {
            val p = time24.split(":")
            p[0].trim().toInt() * 60 + p[1].trim().toInt()
        } catch (e: Exception) {
            0
        }
    }

    /** এখনকার চলমান ওয়াক্ত, পরবর্তী ওয়াক্ত এবং বাকি সেকেন্ড। */
    fun status(timings: List<PrayerTiming>, nowMillis: Long): PrayerStatus? {
        if (timings.isEmpty()) return null
        val sorted = timings.sortedBy { minutesOf(it.startTime) }
        val now = secondsOfDay(nowMillis)

        val current = sorted.lastOrNull { minutesOf(it.startTime) * 60 <= now }
            ?: sorted.lastOrNull { it.id == "isha" } // ফজরের আগে: গতকালের এশা চলছে
        val nextToday = sorted.firstOrNull { minutesOf(it.startTime) * 60 > now }

        return if (nextToday != null) {
            PrayerStatus(current, nextToday, minutesOf(nextToday.startTime) * 60 - now)
        } else {
            val first = sorted.first()
            PrayerStatus(current, first, 24 * 3600 - now + minutesOf(first.startTime) * 60)
        }
    }
}
