package com.salattimebd.app.alarm

import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.core.app.NotificationCompat
import com.salattimebd.app.MainActivity
import com.salattimebd.app.SalatApp
import com.salattimebd.app.util.BengaliUtils

class PrayerAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val prayerId = intent.getStringExtra(PrayerAlarmScheduler.EXTRA_PRAYER_ID) ?: return
        val prayerName = intent.getStringExtra(PrayerAlarmScheduler.EXTRA_PRAYER_NAME) ?: "নামাজ"
        val isReminder = intent.getBooleanExtra(PrayerAlarmScheduler.EXTRA_IS_REMINDER, false)
        val minutesBefore = intent.getIntExtra(PrayerAlarmScheduler.EXTRA_MINUTES_BEFORE, 0)
        val soundMode = intent.getStringExtra(PrayerAlarmScheduler.EXTRA_SOUND_MODE) ?: "default"
        val audioUriString = intent.getStringExtra(PrayerAlarmScheduler.EXTRA_AUDIO_URI)

        val powerManager = context.getSystemService(Context.POWER_SERVICE) as PowerManager
        val wakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "SalatTimeBD:Alarm")
        wakeLock.acquire(10_000L)

        try {
            val channelId = if (isReminder) SalatApp.CHANNEL_PRAYER_REMINDER else SalatApp.CHANNEL_PRAYER_START
            val title = if (isReminder) {
                "$prayerName ওয়াক্তের আর ${BengaliUtils.toBengaliDigits(minutesBefore)} মিনিট বাকি"
            } else {
                "হাইয়্যা আলাস সালাহ! $prayerName ওয়াক্ত শুরু হয়েছে"
            }

            val openIntent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            }
            val pendingIntent = PendingIntent.getActivity(context, prayerId.hashCode(), openIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

            val builder = NotificationCompat.Builder(context, channelId)
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle(title)
                .setContentText("সময়মত জামাতে নামাজ আদায়ের জন্য মসজিদে আসুন।")
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setAutoCancel(true)
                .setContentIntent(pendingIntent)

            val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            vibrator?.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 400, 200, 400), -1))

            if (soundMode == "custom_adhan" && !audioUriString.isNullOrEmpty()) {
                try {
                    MediaPlayer().apply {
                        setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).build())
                        setDataSource(context, Uri.parse(audioUriString))
                        prepare()
                        setOnCompletionListener { it.release() }
                        start()
                    }
                } catch (e: Exception) {
                    // অডিও ফাইল না পেলে শুধু নোটিফিকেশন ও ভাইব্রেশন চলবে
                }
            }

            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val notificationId = (if (isReminder) 200 else 100) + Math.abs(prayerId.hashCode() % 50)
            notificationManager.notify(notificationId, builder.build())
        } finally {
            if (wakeLock.isHeld) wakeLock.release()
        }
    }
}