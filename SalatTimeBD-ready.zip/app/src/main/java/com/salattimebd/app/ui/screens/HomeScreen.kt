package com.salattimebd.app.ui.screens

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.salattimebd.app.data.preferences.PrayerAlarmConfig
import com.salattimebd.app.data.preferences.UserSettings
import com.salattimebd.app.data.repository.DailyPrayerData
import com.salattimebd.app.data.repository.Resource
import com.salattimebd.app.util.BengaliUtils
import com.salattimebd.app.util.PrayerClock
import com.salattimebd.app.util.PrayerTiming
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    prayerDataState: Resource<DailyPrayerData>,
    userSettings: UserSettings,
    onManualRefresh: () -> Unit,
    onNavigateToSettings: () -> Unit,
    onNavigateToDiagnostics: () -> Unit,
    onAlarmToggle: (String, Boolean) -> Unit,
    onSaveAlarmConfig: (String, PrayerAlarmConfig) -> Unit,
    onSelectAudio: (String) -> Unit,
    onPreviewAudio: (String, String?) -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("নামাজের সময় বিডি", fontWeight = FontWeight.Bold) },
                actions = {
                    IconButton(onClick = onManualRefresh) {
                        Icon(Icons.Default.Refresh, contentDescription = "রিফ্রেশ")
                    }
                    IconButton(onClick = onNavigateToDiagnostics) {
                        Icon(Icons.Default.Info, contentDescription = "ডায়াগনস্টিকস")
                    }
                    IconButton(onClick = onNavigateToSettings) {
                        Icon(Icons.Default.Settings, contentDescription = "সেটিংস")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary,
                    actionIconContentColor = MaterialTheme.colorScheme.onPrimary
                )
            )
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
        ) {
            when (prayerDataState) {
                is Resource.Loading -> {
                    CircularProgressIndicator(modifier = Modifier.align(Alignment.Center))
                }

                is Resource.Error -> {
                    Column(
                        modifier = Modifier
                            .align(Alignment.Center)
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Text(prayerDataState.message, textAlign = TextAlign.Center)
                        Button(onClick = onManualRefresh) { Text("আবার চেষ্টা করুন") }
                    }
                }

                is Resource.Success -> {
                    PrayerList(
                        data = prayerDataState.data,
                        userSettings = userSettings,
                        onAlarmToggle = onAlarmToggle,
                        onSaveAlarmConfig = onSaveAlarmConfig,
                        onSelectAudio = onSelectAudio,
                        onPreviewAudio = onPreviewAudio
                    )
                }
            }
        }
    }
}

@Composable
private fun PrayerList(
    data: DailyPrayerData,
    userSettings: UserSettings,
    onAlarmToggle: (String, Boolean) -> Unit,
    onSaveAlarmConfig: (String, PrayerAlarmConfig) -> Unit,
    onSelectAudio: (String) -> Unit,
    onPreviewAudio: (String, String?) -> Unit
) {
    var nowMillis by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(1000)
            nowMillis = System.currentTimeMillis()
        }
    }

    val bn = userSettings.useBengaliNumerals
    val status = PrayerClock.status(data.timings, nowMillis)

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        data.locationName,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                    Text(
                        BengaliUtils.localize(data.gregorianDateBn, bn),
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                    if (data.hijriDateBn.isNotEmpty()) {
                        Text(
                            BengaliUtils.localize(data.hijriDateBn, bn),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                    if (status != null) {
                        Text(
                            "এখন: ${status.current?.nameBn ?: "-"}",
                            modifier = Modifier.padding(top = 8.dp),
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Text(
                            "${status.next.nameBn} শুরু হতে বাকি: ${BengaliUtils.formatCountdown(status.secondsToNext, bn)}",
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                    if (data.fromCache) {
                        Text(
                            "অফলাইন: সংরক্ষিত সময়সূচি দেখানো হচ্ছে",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                }
            }
        }

        items(data.timings, key = { it.id }) { timing ->
            PrayerCard(
                timing = timing,
                isCurrent = status?.current?.id == timing.id,
                alarm = userSettings.alarmFor(timing.id),
                useBengali = bn,
                onAlarmToggle = onAlarmToggle,
                onSaveAlarmConfig = onSaveAlarmConfig,
                onSelectAudio = onSelectAudio,
                onPreviewAudio = onPreviewAudio
            )
        }
    }
}

@Composable
private fun PrayerCard(
    timing: PrayerTiming,
    isCurrent: Boolean,
    alarm: PrayerAlarmConfig,
    useBengali: Boolean,
    onAlarmToggle: (String, Boolean) -> Unit,
    onSaveAlarmConfig: (String, PrayerAlarmConfig) -> Unit,
    onSelectAudio: (String) -> Unit,
    onPreviewAudio: (String, String?) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = if (isCurrent) MaterialTheme.colorScheme.primaryContainer
            else MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        timing.nameBn,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        "শুরু: ${BengaliUtils.formatTime12(timing.startTime, useBengali)}",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Text(
                        "শেষ: ${BengaliUtils.formatTime12(timing.endTime, useBengali)}",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                if (timing.isObligatory) {
                    Switch(
                        checked = alarm.enabled,
                        onCheckedChange = { onAlarmToggle(timing.id, it) }
                    )
                }
                IconButton(onClick = { expanded = !expanded }) {
                    Icon(
                        if (expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                        contentDescription = "বিস্তারিত"
                    )
                }
            }

            if (expanded) {
                Column(
                    modifier = Modifier.padding(top = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(timing.fiqhRuleDescriptionBn, style = MaterialTheme.typography.bodySmall)

                    if (timing.isObligatory) {
                        Text("ওয়াক্তের আগে রিমাইন্ডার", fontWeight = FontWeight.Medium)
                        Row(
                            modifier = Modifier.horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf(0, 5, 10, 15, 30).forEach { m ->
                                FilterChip(
                                    selected = alarm.minutesBefore == m,
                                    onClick = { onSaveAlarmConfig(timing.id, alarm.copy(minutesBefore = m)) },
                                    label = {
                                        Text(
                                            if (m == 0) "নেই"
                                            else "${BengaliUtils.localize(m.toString(), useBengali)} মিনিট"
                                        )
                                    }
                                )
                            }
                        }

                        Text("এলার্মের শব্দ", fontWeight = FontWeight.Medium)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(
                                selected = alarm.soundMode == "default",
                                onClick = { onSaveAlarmConfig(timing.id, alarm.copy(soundMode = "default")) },
                                label = { Text("ডিফল্ট") }
                            )
                            FilterChip(
                                selected = alarm.soundMode == "custom_adhan",
                                onClick = { onSaveAlarmConfig(timing.id, alarm.copy(soundMode = "custom_adhan")) },
                                label = { Text("নিজের আজান") }
                            )
                        }

                        if (alarm.soundMode == "custom_adhan") {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(onClick = { onSelectAudio(timing.id) }) {
                                    Text(if (alarm.customAudioUri.isNullOrEmpty()) "অডিও বেছে নিন" else "অডিও বদলান")
                                }
                                if (!alarm.customAudioUri.isNullOrEmpty()) {
                                    OutlinedButton(onClick = { onPreviewAudio(alarm.soundMode, alarm.customAudioUri) }) {
                                        Text("শুনে দেখুন")
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
